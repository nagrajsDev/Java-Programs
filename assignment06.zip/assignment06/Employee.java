package assignment06;

public class Employee implements Comparable<Employee> {

	private Integer id;
	private String name;
	private String role;
	private Double salary;

	public Employee(Integer id, String name, String role, Double salary) {
		super();
		this.id = id;
		this.name = name;
		this.role = role;
		this.salary = salary;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	

	@Override
	public String toString() {
		return "Employee Id=" + id + ", Name=" + name + ", Role=" + role + ", Salary=" + salary;
	}

	@Override
	public int compareTo(Employee o) {
		if (this.id < o.getId())
			return -1;

		else if (this.id > o.getId())
			return 1;
		else
			return 0;

	}

}
