package assignment06;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class MainApplication {
	private static ArrayList<Employee> list = new ArrayList();

	public static void main(String[] args) throws IOException {
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter name of the employee data file: \n");
		String fileName = input.nextLine();
		readEmployeeData(fileName);
		boolean enable = true;
		while (enable) {
			System.out.println(
					"Select an option from below:\nSelect 1. sort employees by Employee ID \nSelect 2. sort employees by Salary\nSelect 3. sort employees by Name\nSelect 4. sort employees by Role\n");
			int choice = input.nextInt();
			if (choice == 1) {
				Collections.sort(list);
				printAll();
				enable = goBack();
			}

			else if (choice == 2) {
				sortBySalary();
				enable = goBack();
			} else if (choice == 3) {
				sortByName();
				enable = goBack();
			} else if (choice == 4) {
				sortByRole();
				enable = goBack();
			}

		}
		
		System.out.println("\n\n=============== THANK YOU ================");

	}

	private static void readEmployeeData(String fileName) throws IOException {
		String line;
		String[] data;

		try {
			File file = new File("E:\\Java Practice\\Java Programs\\src\\assignment06\\" + fileName+".txt");
			FileReader fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);

			while ((line = br.readLine()) != null) {
				data = line.split(" ");
				Employee employee = new Employee(Integer.parseInt(data[0]), data[1], data[2],
						Double.parseDouble(data[3]));
				list.add(employee);
			}
			br.close();
		} catch (FileNotFoundException e) {
			System.out.println(
					"File is not available/ you have entered wrong file name\nPlease enter the Correct File name");
			readEmployeeData(new Scanner(System.in).next());
		}

	}

	public static void sortBySalary() {
		System.out.println("Select 1 for Lowest to Highest Pay\nSelect 2 for Highest to lowest Pay");
		int choice = new Scanner(System.in).nextInt();
		Comparator<Employee> comparator;
		if (choice == 1) {
			comparator = new Comparator<Employee>() {

				@Override
				public int compare(Employee o1, Employee o2) {

					return o1.getSalary().compareTo(o2.getSalary());
				}
			};
			Collections.sort(list, comparator);
			printAll();
		} else if (choice == 2) {
			comparator = new Comparator<Employee>() {

				@Override
				public int compare(Employee o1, Employee o2) {

					return -o1.getSalary().compareTo(o2.getSalary());
				}
			};
			Collections.sort(list, comparator);
			printAll();
		} else {
			System.out.println("\nYou have entered wrong option, choose again: ");
			sortBySalary();
		}
	}

	public static void sortByName() {
		Comparator<Employee> comparator = new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {

				return o1.getName().compareTo(o2.getName());
			}
		};
		Collections.sort(list, comparator);
		printAll();
	}

	public static void sortByRole() {
		Comparator<Employee> comparator = new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {

				return o1.getRole().compareTo(o2.getRole());
			}
		};

		Collections.sort(list, comparator);
		printAll();
	}

	public static void printAll() {
		for (Employee employee : list) {
			System.out.println(employee);
		}
	}

	public static boolean goBack() {
		System.out.println("\nDo you want to go back ? (yes/no)");
		String str = new Scanner(System.in).next();
		if (str.equalsIgnoreCase("yes"))
			return true;

		else if (str.equalsIgnoreCase("no"))
			return false;

		else {
			System.out.println("You have entered wrong option, enter again: ");
			return goBack();
		}
	}

}
