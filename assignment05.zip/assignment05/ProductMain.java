package assignment05;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class ProductMain {
	
	

	public static void main(String[] args) {
		
		HashSet<Product> set=new HashSet<Product>();
		
		
		set.add(new Product(123,"Dell",4,51000.00));
		set.add(new Product(124,"Lenovo",8,49000.00));
		set.add(new Product(125,"Mac",8,125000.00));
		set.add(new Product(129,"HP",8,165000.00));
		
		TreeSet<Product> ts= new TreeSet<Product>(set);
		
		ProductMain pm=new ProductMain();
		
		for(Product p: ts)
		{
			System.out.println(p);
		}
		

	}

}
