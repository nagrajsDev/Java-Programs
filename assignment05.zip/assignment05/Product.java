package assignment05;

import java.util.Comparator;

public class Product implements Comparable<Product>
{
	private int serialNumber;
	private String brand;
	private int ram;
	private Double price;
	
	public Product(int serialNumber, String brand, int ram, Double price) {
		super();
		this.serialNumber = serialNumber;
		this.brand = brand;
		this.ram = ram;
		this.price = price;
	}
	public int getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public int getRam() {
		return ram;
	}
	public void setRam(int ram) {
		this.ram = ram;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [serialNumber=" + serialNumber + ", brand=" + brand + ", ram=" + ram + ", price=" + price + "]";
	}
	@Override
	public int compareTo(Product o) {
		if(this.price<o.getPrice())
		{
			return -1;
		}
		else if(this.price>o.getPrice())
		{
			return 1;
		}
		else if(this.price==o.getPrice())
		{
			return 0;
		}
		else
		{
			return 0;
		}
		
	}
	
	
	
	
	
	

}
