package assignment01;

import java.util.ArrayList;
import java.util.Scanner;

public class ApplicationMain {
	public static void main(String[] args) {
		Employee employee=new Employee();
		Scanner input=new Scanner(System.in);
		System.out.println("Enter employee Name: ");
		employee.setEmployeeName(input.nextLine());
		System.out.println("Count of mobile numbers: ");
		int count=input.nextInt();
		ArrayList<String> list=new ArrayList<String>();
		for (int i = 0; i <count; i++) {
			System.out.println(i+1+" Enter Mobile number: ");
			list.add(input.next());
		}
		employee.setEmployeeMobileNumber(list);
		
		System.out.println("Employee Salary: ");
		employee.setEmployeeSalary(input.nextLong());
		
		System.out.println("Enter email address: ");
		employee.setEmployeeEmail(input.next());
		
		System.out.println("Enter the complete address line1, line2, city and pincode: ");
		employee.setAddress(new Address(input.nextLine(), input.nextLine(), input.nextLine(), input.next()));
		input.nextLine();
		
		
		System.out.println("\n\n\nEmployee details are: ");
		employee.display();
		
		
		
	}

}
