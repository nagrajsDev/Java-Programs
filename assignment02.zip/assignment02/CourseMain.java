package assignment02;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CourseMain {

	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);
		ArrayList<Course> list=new ArrayList<Course>();
		list.add(new Course("Java", "Sathish", 1000.0));
		list.add(new Course("Selenium", "Kanimozhi", 2000.0));
		list.add(new Course("Python", "Arun", 500.0));
		
		CourseList course=new CourseList();
		for (int i = 0; i <3; i++) {
			course.setCourseList(list);
			
		}
		
		System.out.println("Enter your budget: ");
		double budget=input.nextDouble();
		
		List<String> data=new ArrayList<String>();
		
		for (int i = 0; i <list.size(); i++) 
		{
			if(budget>=list.get(i).getFee())
			{
				data.add(list.get(i).getName());
			}
			
		}
		
		if(data.isEmpty())
		{
			System.out.println("No Course available");
		}
		else
		{
			int i=1;
			for(String str:data)
			{
				
				System.out.println(str+" -"+i++);
			}
		}
		
		
		
		

	}

}
