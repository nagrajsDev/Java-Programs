package assignment02;

import java.util.ArrayList;

public class CourseList {

	private ArrayList<Course> courseList;
	
	

	

	public ArrayList<Course> getCourseList() {
		return courseList;
	}

	public void setCourseList(ArrayList<Course> courseList) {
		this.courseList = courseList;
	}
	
	

	public void insert(Course course) {
		courseList.add(course);
	}

	public ArrayList<String> noOfCouse(Double budget) {

		
		new ArrayList<String>().add("Java-1");
		new ArrayList<String>().add("Python-2");
		return new ArrayList<String>();

	}
}
