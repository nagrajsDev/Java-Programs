package assignment04;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class CourseList {

	private ArrayList<Course> courseList;

	public ArrayList<Course> getCourseList() {
		return courseList;
	}

	public void setCourseList(ArrayList<Course> courseList) {
		this.courseList = courseList;
	}

	public void insert(Course course) {
		courseList.add(course);
	}

	public double revenue() {
		double totalFare = 0;
		double result = 0;
		for (int i = 0; i < courseList.size(); i++) {

			totalFare = totalFare + courseList.get(i).getFee() * 200;
			result = result + (totalFare * 0.2);

		}

		return result;

	}
}
