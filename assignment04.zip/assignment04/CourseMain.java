package assignment04;

import java.util.ArrayList;
import java.util.Iterator;

public class CourseMain {

	public static void main(String[] args) {
		ArrayList<Course> list = new ArrayList<Course>();
		list.add(new Course("Java", "Sathish", 1000.0));
		list.add(new Course("Selenium", "Kanimozhi", 2000.0));
		list.add(new Course("Python", "Arun", 500.0));

		CourseList cl = new CourseList();

		cl.setCourseList(list);
		System.out.println("Total Revenue: "+cl.revenue());

	}

}
