package assignment03;

public class Course 
{
	private String name;
	private String mentor;
	private Double fee;
	
	public Course(String name, String mentor, Double fee) {
		super();
		this.name = name;
		this.mentor = mentor;
		this.fee = fee;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMentor() {
		return mentor;
	}
	public void setMentor(String mentor) {
		this.mentor = mentor;
	}
	public Double getFee() {
		return fee;
	}
	public void setFee(Double fee) {
		this.fee = fee;
	}
	
	public void display()
	{
		System.out.println("Course Details: \nname= "+getName()+"\n Mentor= "+getMentor()+"\nFree= "+getFee());
	}
	@Override
	public String toString() {
		return "Course [name=" + name + ", mentor=" + mentor + ", fee=" + fee + "]";
	}
	

}
