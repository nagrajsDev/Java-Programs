package assignment03;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class CourseList {

	private ArrayList<Course> courseList;

	public ArrayList<Course> getCourseList() {
		return courseList;
	}

	public void setCourseList(ArrayList<Course> courseList) {
		this.courseList = courseList;
	}

	public void insert(Course course) {
		courseList.add(course);
	}

	public void discount() {
		Comparator<Course> comparator = new Comparator<Course>() {

			@Override
			public int compare(Course o1, Course o2) {

				return o1.getFee().compareTo(o2.getFee());
			}
		};

		Collections.sort(courseList, comparator);

		if (courseList.get(courseList.size() - 1).getFee() > courseList.get(0).getFee()) {
			double amount = courseList.get(courseList.size() - 1).getFee();
			double discount = courseList.get(courseList.size() - 1).getFee() * 0.10;
			courseList.get(courseList.size() - 1).setFee(amount - discount);
			System.out.println(
					"Discount " + discount + " for " + courseList.get(courseList.size() - 1).getName() + " Course");
		}
		if (courseList.get(0).getFee() != 0) {
			double amount = courseList.get(0).getFee();
			double discount = courseList.get(0).getFee() * 0.05;
			courseList.get(0).setFee(amount - discount);
			System.out.println("Discount " + discount + " for " + courseList.get(0).getName() + " Course");

		}

	}
}
